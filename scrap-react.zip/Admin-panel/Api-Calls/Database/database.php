<?php

$host = "localhost";
$password = "";
$username= "root";
$db = "admin_panel";
$conn = mysqli_connect($host,$username,$password,$db) or die("Connection Failed");
